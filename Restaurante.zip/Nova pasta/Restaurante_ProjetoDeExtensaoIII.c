#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<string.h>

typedef struct RestauranteKilo{
    char *meses[12];
	float peso;
    float preco;
    float valorDia;
    float valorMensal[12];
	int quantidade;
}entradas;

float valorComida(float peso) {
    float precoRefeicao = 6;
    return (precoRefeicao) * (peso/100);
}

void Ordenar(char **meses, float *valorMensal) {
    int i, j;
    int n = 12;
    float temp;
    char *tempMes;
    for (i = 1; i < n; i++) {
        temp = valorMensal[i];
        tempMes = meses[i];
        for(j = i-1; j >= 0 && valorMensal[j] < temp ; j--) {
            valorMensal[j+1] = valorMensal[j];
            meses[j+1] = meses[j];
        }
        valorMensal[j+1] = temp;
        meses[j+1] = tempMes;
    }
    printf("\n\n");
    for (i = 0; i < n; i++) {
        printf("\t%s - R$%.2f\n", meses[i], valorMensal[i]);
    }   
    printf("\n");
}

void registrarQuentinhas(entradas *userE) {
    int userX, i;
    printf("\tQuentinhas vendidas: ");
    scanf("%d", &userX);
    for(i = 0; i < userX; i++){
        userE->valorDia += 20.50;
    }
    printf("\n\n");
    printf("\t%d quentinhas registradas\n", userX);
    printf("\n");
}

void registrarSelfService(entradas* userE) {
    int numMarmitas, i;
    printf("\tMarmitas vendidas: ");
    scanf("%d", &numMarmitas);
    for(i = 0; i < numMarmitas; i++) {
        float peso;
        printf("\tPeso (em gramas) da Marmita %d: ", i+1);
        scanf("%f", &peso);
        float precoMarmita = valorComida(peso);
        userE->valorDia += precoMarmita;
    }
    printf("\n\n");
    printf("\t%d refeicoes registradas\n", numMarmitas);
    printf("\n");
}

void registrarRefrigerantes(entradas* userE) {
    int numBebidas, i;
    printf("\tRefrigerantes vendidos: ");
    scanf("%d", &numBebidas);
    for(i = 0; i < numBebidas; i++) {
        userE->valorDia += 6.0;
    }
    printf("\n\n");
    printf("\t%d refrigerantes registrados\n", numBebidas);
    printf("\n");
}

void finalizarMes(entradas* userE) {
    int mes;
    printf("\tDigite o n�mero do m�s que deseja finalizar (1-12): ");
    scanf("%d", &mes);
    if (mes < 1 || mes > 12) {
        printf("\tM�s inv�lido!\n");
        return;
    }
    mes--;
    userE->valorMensal[mes] = userE->valorDia;
    printf("\n\tM�s de %s finalizado - total de vendas: R$%.2f\n", userE->meses[mes], userE->valorMensal[mes]);
    userE->valorDia = 0;
}

void relatorioAnual(entradas userE) {
	int i;
    printf("\n\tRelat�rio anual de vendas\n");
    for (i = 0; i < 12; i++) {
        printf("\t%s - R$%.2f\n", userE.meses[i], userE.valorMensal[i]);
    }
}


int main(){

    setlocale(LC_ALL, "Portuguese");

  	int i,x,userX, escolha = 0;
  	entradas userE = {{"Janeiro", "Fevereiro", "Mar�o", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"},0, 0, 0, 0, {0}};

    printf("\t          EAT FOREVER\n");
    printf("\tUma experi�ncia gastron�mica infinita\n\n");
    printf("\tBem-vindo(a)!\n");
	
    while (escolha != 8) {
    	
        printf("\n        escolhas:\n");
        
        printf("\t1. Entradas Quentinhas\n");
        printf("\t2. Entradas Self-Service\n");
        printf("\t3. Entradas Refrigerantes\n");
        printf("\t4. Valor total do dia\n");
        printf("\t5. Finalizar mes de vendas\n");
        printf("\t6. Relat�rio anual\n");
        printf("\t7. Relat�rio anul organizado\n");
        printf("\t8. Encerrar\n");
        printf("\n\n");
        
        printf("\tDigite a escolha desejada: ");
        scanf("%d", &escolha);

        switch (escolha) {
            case 1:
            	registrarQuentinhas(&userE);
            	sleep(2);
                break;
                
            case 2:
				registrarSelfService(&userE);
				sleep(2);
                break;
                
            case 3:
				registrarRefrigerantes(&userE);
				sleep(2);
                break;
                
            case 4: 
            	printf("\n\n");
            	printf("\tValor total de vendas no mes: R$%.2f\n", userE.valorDia);
				printf("\n");
				sleep(2);
            	break;
                
            case 5:
			    finalizarMes(&userE);
			    sleep(2);
			    break;
			case 6:
			    relatorioAnual(userE);
			    sleep(2);
			    break;

            case 7:
            	Ordenar(userE.meses, userE.valorMensal);
            	sleep(2);
            	break;

            case 8:	
                printf("\tEncerrando o programa...\n");
                sleep(1);
                break;
                
            default:
                printf("\tErro na opera��o. Tente novamente.\n");
                sleep(1);
                break;
        }
        
    }

    return 0;
}
